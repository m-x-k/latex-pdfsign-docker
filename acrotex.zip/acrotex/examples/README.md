AeB Examples folder

Contents:
    1.  test_install.pdf : To verify that you correctly installed aeb.js, for
        Distiller users only, open this file in Acrobat and follow the directions.
    2.  webeqtst.tex : Basic file highlighting feature of web and exerquiz
        (exercises and multiple choice quizzes).
    3.  jquiztst.tex : Features math fill-in quizzes of exerquiz.
    4.  jtxttst.tex : Features text fill-in question of exerquiz.

There are numerous other examples available, the resources are
    1.  The full collection of AeB distribution files are located at
        http://www.acrotex.net/blog/?cat=89
    2.  Demo files whose focus is the web package are
        http://www.acrotex.net/blog/?tag=web-package
    3.  Demo file whose focus is the exerquiz package are
        http://www.acrotex.net/blog/?tag=exerquiz
    4.  Demo files for the dljslib package are
        http://www.acrotex.net/blog/?tag=dljslib
    5.  Demo files with focus on the extended or pro option of web are here:
        http://www.acrotex.net/blog/?tag=extended-option

The AcroTeX Blog (http://www.acrotex.net/blog/) is a great resource for all things
AeB and PDF.

Don Story
2016/01/29
